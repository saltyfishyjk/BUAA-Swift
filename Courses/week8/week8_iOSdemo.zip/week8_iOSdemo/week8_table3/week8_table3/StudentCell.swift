//
//  StudentCell.swift
//  week8_table3
//
//  Created by jinshenghao on 2022/10/24.
//

import Foundation

import UIKit

class StudentCell : UITableViewCell {
    
    @IBOutlet var name: UILabel!
    
    @IBOutlet var number: UILabel!
    
    @IBOutlet var score: UILabel!
}
