//
//  ViewController.swift
//  week8_table3
//
//  Created by jinshenghao on 2022/10/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

