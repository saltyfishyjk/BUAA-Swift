//
//  Students.swift
//  week8_table1
//
//  Created by jinshenghao on 2022/10/24.
//

import Foundation
import UIKit

class Student : NSObject {
    var name : String
    var score : Int
    var id : String
    
    init(name : String, score : Int, id : String) {
        self.score = score
        self.name = name
        self.id = id
        super.init()
    }
}
