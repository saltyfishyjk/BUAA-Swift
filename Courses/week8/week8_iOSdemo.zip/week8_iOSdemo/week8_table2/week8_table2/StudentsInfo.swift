//
//  StudentsInfo.swift
//  week8_table1
//
//  Created by jinshenghao on 2022/10/24.
//

import Foundation
import UIKit

class studentInfo {
    var studentsCollection = [Student]()
    
    init() {
        let a = Student(name : "路人甲", score : 99)
        let b = Student(name : "路人乙", score : 98)
        let c = Student(name : "路人丙", score : 100)
        studentsCollection.append(a)
        studentsCollection.append(b)
        studentsCollection.append(c)
    }
    
    // 添加一个写死的学生数据
    func addStudent() -> Student {
        let newStudent = Student(name : "Student", score : 100)
        studentsCollection.append(newStudent)
        return newStudent
    }
    
    // 删除特定student
    func delStudent(theStudent : Student) {
        if let index = studentsCollection.firstIndex(of: theStudent) {
            studentsCollection.remove(at: index)
        }
    }
    
    // 更改student位置，不是交换
    func trans(from : Int, to : Int) {
        let theStudent = studentsCollection[from]
        studentsCollection.remove(at: from)
        studentsCollection.insert(theStudent, at: to)
    }
    
    
}
