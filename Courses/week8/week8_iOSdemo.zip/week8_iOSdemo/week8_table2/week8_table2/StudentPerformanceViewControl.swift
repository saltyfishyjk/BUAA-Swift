//
//  StudentPerformanceViewControl.swift
//  week8_table1
//
//  Created by jinshenghao on 2022/10/24.
//

import Foundation
import UIKit

class StudentPerformanceViewControl : UITableViewController {
    var studentInfo1 : studentInfo! = studentInfo()
    
    // 有多少行
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentInfo1.studentsCollection.count
    }
    
    // 返回每一个cell 对象，表格每行是一个cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UITableViewCell", for: indexPath)
        let student = studentInfo1.studentsCollection[indexPath.row]
        cell.textLabel?.text = student.name
        cell.detailTextLabel?.text = String(student.score)
        return cell
    }
    
    override func viewDidLoad() {
        let barHeight = view.window?.windowScene?.statusBarManager?.statusBarFrame.height ?? 30
        let insets = UIEdgeInsets(top: barHeight, left: 0, bottom: 0, right: 0)
        tableView.contentInset = insets
        tableView.scrollIndicatorInsets = insets
    }
    
    @IBAction func switchMode(_ sender: Any) {
        if isEditing {
            (sender as! UIButton).setTitle("Edit Mode", for: .normal)
            setEditing(false, animated: true)
        } else {
            (sender as! UIButton).setTitle("Submit", for: .normal)
            setEditing(true, animated: true)
        }
    }
    
    @IBAction func add_student(_ sender: Any) {
        let theStudent = studentInfo1.addStudent()
        if let index = studentInfo1.studentsCollection.firstIndex(of: theStudent) {
            let indexpath = IndexPath(row: index, section: 0)
            tableView.insertRows(at: [indexpath], with: .automatic)
        }
    }
    
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            let student = studentInfo1.studentsCollection[indexPath.row]
            studentInfo1.delStudent(theStudent: student)
            tableView.deleteRows(at: [indexPath], with: .automatic)
        }
    }
    
    override func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        studentInfo1.trans(from: sourceIndexPath.row, to: destinationIndexPath.row)
    }
}
