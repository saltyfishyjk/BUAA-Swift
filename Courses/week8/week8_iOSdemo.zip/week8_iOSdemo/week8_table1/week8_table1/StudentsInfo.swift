//
//  StudentsInfo.swift
//  week8_table1
//
//  Created by jinshenghao on 2022/10/24.
//

import Foundation
import UIKit

class studentInfo {
    var studentsCollection = [Student]()
    
    init() {
        let a = Student(name : "路人甲", score : 99)
        let b = Student(name : "路人乙", score : 98)
        let c = Student(name : "路人丙", score : 100)
        studentsCollection.append(a)
        studentsCollection.append(b)
        studentsCollection.append(c)
    }
}
