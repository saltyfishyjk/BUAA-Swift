//
//  StudentPerformanceViewControl.swift
//  week8_table1
//
//  Created by jinshenghao on 2022/10/24.
//

import Foundation
import UIKit

class StudentPerformanceViewControl : UITableViewController {
    var studentInfo1 : studentInfo! = studentInfo()
    
    // 有多少行
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return studentInfo1.studentsCollection.count
    }
    
    // 返回每一个cell 对象，表格每行是一个cell
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UITableViewCell", for: indexPath)
        let student = studentInfo1.studentsCollection[indexPath.row]
        cell.textLabel?.text = student.name
        cell.detailTextLabel?.text = String(student.score)
        return cell
    }
    
    override func viewDidLoad() {
        let barHeight = view.window?.windowScene?.statusBarManager?.statusBarFrame.height ?? 30
        let insets = UIEdgeInsets(top: barHeight, left: 0, bottom: 0, right: 0)
        tableView.contentInset = insets
        tableView.scrollIndicatorInsets = insets
    }
}
